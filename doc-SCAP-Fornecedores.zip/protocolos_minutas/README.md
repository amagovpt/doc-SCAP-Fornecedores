# Informação

Utilize a minuta prefixada com ARTE. 

A minuta prefixada com AMA é exatamente idêntica e serve apenas o propósito de evitar hiperligações quebradas em sistemas onde o nome da minuta não foi ainda atualizado.